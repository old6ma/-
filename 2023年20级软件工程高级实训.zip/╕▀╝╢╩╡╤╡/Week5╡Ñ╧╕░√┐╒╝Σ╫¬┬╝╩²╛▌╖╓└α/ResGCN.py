import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
from sklearn.metrics import classification_report
from torch_geometric.nn import GCNConv
import torch.nn.functional as F
from torch_geometric.data import Data
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE


class GraphConvLayer(nn.Module):
    def __init__(self, in_features, out_features):
        super(GraphConvLayer, self).__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, x, adjacency_matrix):
        t = self.linear(x)
        #图像卷积操作
        adjacency_matrix = adjacency_matrix.to(x.dtype)

        x_gcn = torch.matmul(adjacency_matrix, t)

        return x_gcn

class ResidualGraphConvolutionBlock(nn.Module):
    def __init__(self, in_features, out_features):
        super(ResidualGraphConvolutionBlock, self).__init__()
        self.conv1 = GraphConvLayer(in_features, out_features)
        self.conv2 = GraphConvLayer(out_features, out_features)
        #残差连接，维度削减
        self.shortcut = nn.Linear(in_features, out_features)

    def forward(self, x, adjacency_matrix):
        residual = x
        #有两层图像的卷积操作
        x_gcn = F.relu(self.conv1(x, adjacency_matrix))
        x_gcn = self.conv2(x_gcn, adjacency_matrix)
        #残差连接
        #首先对维度进行变换以达到维度一致的目的
        shortcut = self.shortcut(residual)
        #将图卷积的特征与残差结果相加，使得学习的残差结果可以添加到前一层
        x_gcn += shortcut

        x_gcn = F.relu(x_gcn)

        return x_gcn


# train_df是1752*48的Dataframe
train_df = pd.read_csv("st_training_set.csv", index_col=0)
# test_df是1800*48的Dataframe
test_df = pd.read_csv("st_test_set.csv", index_col=0)
# 把test_df与data_df合并，此时训练集数据的索引为0~1751，测试集的索引为1752~3551
df = pd.concat((train_df, test_df))
# 构建一个数值在0~1751的一维张量作为训练集的mask（此时训练集数据的索引为0~1751）
train_mask = torch.arange(train_df.shape[0])
# 构建一个数值在1752~3551的一维张量作为测试集的mask（此时测试集的索引为1752~3551）
test_mask = torch.arange(train_df.shape[0], df.shape[0])

threshold = 10
dis_matrix = np.zeros((df.shape[0], df.shape[0]))
# 取数据中x、y列的坐标值作为每个细胞的位置
pos = df.iloc[:, -4:-2].values
for i in range(len(pos)):
    for j in range(i + 1, len(pos)):
        distance = np.linalg.norm(pos[i] - pos[j])
        if distance < threshold:
            dis_matrix[i, j] = 1
            dis_matrix[j, i] = 1
            print(1)
        else:
            dis_matrix[i, j] = 0
            dis_matrix[j, i] = 0
np.fill_diagonal(dis_matrix, 0)
# 获得每条边所连接的两个点的索引
edge_list = np.transpose(np.nonzero(dis_matrix))

# 每个细胞的所有44个基因的特征值
x = df.iloc[:, :-4].values
# 细胞类型
y = df['cell_type'].values
# type=list()
# type.append(y[0])
#
# for i in range(len(y)):
#     has_type=False
#     for j in range(len(type)):
#         if y[i]==type[j]:
#             has_type=True
#             break
#     if not has_type:
#         type.append(y[i])
# print(len(type))
# labelEncoder用于把标签转化为整数类型
le = LabelEncoder()
y = le.fit_transform(y)
# x=torch.FloatTensor(x)
# y=torch.LongTensor(y)
num_features=44
hidden_size=64
num_classes=9
num_layers=3

#dataset for residual
dataset = Data(x=torch.FloatTensor(x).unsqueeze(0),
               edge_index=torch.LongTensor(dis_matrix).T,
               y=torch.LongTensor(y).unsqueeze(0))
# dataset = Data(x=torch.FloatTensor(x),
#                edge_index=torch.LongTensor(edge_list).T,
#                y=torch.LongTensor(y))
dataset.train_mask = train_mask
dataset.test_mask = test_mask

classes = np.unique(dataset.y).shape[0]


class ResGCN(nn.Module):
    def __init__(self, num_features, hidden_size, num_classes, num_blocks):
        super(ResGCN, self).__init__()
        self.init_conv = GraphConvLayer(num_features, hidden_size)

        # 残差卷积层
        self.res_blocks = nn.ModuleList([ResidualGraphConvolutionBlock(hidden_size, hidden_size) for _ in range(num_blocks)])

        # 全连接层
        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, data):
        x,adjacency_matrix=data.x,data.edge_index
        #图卷积操作
        x = F.relu(self.init_conv(x, adjacency_matrix))
        # 残差卷积操作
        for block in self.res_blocks:
            x = block(x, adjacency_matrix)

        x = self.fc(x)

        return F.log_softmax(x, dim=2)


# class GCN(torch.nn.Module):
#
#     def __init__(self, input_dim, hidden_dimension, classes):
#         super(GCN, self).__init__()
#         # GCNConv函数是GCN网络的卷积层，用于计算每一层结点的特征（根据学习报告中的原理），有两个参数分别是输入特征通道数与输出特征通道数
#         # 第一层卷积层把每个结点的特征维度传入到中间层上，所以第一层的输入输出特征通道数分别为输入结点特征维度与隐藏层维度
#         self.conv1 = GCNConv(input_dim, hidden_dimension)
#         # 第二层把中间层的特征映射到最终的类别上，比如Cora数据集最终要辨别7种论文，那么对应的输出特征维度就为7
#         self.conv2 = GCNConv(hidden_dimension, classes)
#
#     def forward(self, data):
#         # 传入结点与边（即节点的邻接关系）
#         x, edge_index = data.x, data.edge_index
#         # 把结点与邻接关系导入第一层卷积，网络会根据输入特征和边关系来执行图卷积操作，将特征传给邻居节点
#         x = self.conv1(x, edge_index)
#         # 激活函数
#         x = x.relu()
#         # dropout层用于防止过拟合
#         x = F.dropout(x, training=self.training)
#         # 把上一层处理好的特征再传入下一层卷积层，作用与第一层一样，区别在于输出的特征维度已经是dataset.num_classes了
#         x = self.conv2(x, edge_index)
#         # 使用softmax得到概率分布
#         x = F.log_softmax(x, dim=1)
#         return x

def visualize(h, color):
    z = TSNE(n_components=2).fit_transform(h.detach().cpu().numpy())

    plt.figure(figsize=(10, 10))
    plt.xticks([])
    plt.yticks([])

    plt.scatter(z[:, 0], z[:, 1], s=70, c=color, cmap="Set2")
    plt.show()


model = ResGCN(num_features, hidden_size, num_classes, num_layers)

optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=0.001)
out = model(dataset)
visualize(out[0], color=dataset.y)
model.train()
for epoch in tqdm(range(300)):
    optimizer.zero_grad()
    out = model(dataset)
    t_out=out[0]
    # t_y=dataset.y
    # t_y=t_y.reshape(-1, t_y.size(-1))
    # t_out=t_out.reshape(-1)
    # t=t_y[0]
    t_y=torch.LongTensor(y)
    loss = F.nll_loss(t_out[dataset.train_mask], t_y[dataset.train_mask])
    loss.backward()
    optimizer.step()

model.eval()
pred = model(dataset)
visualize(pred[0], color=dataset.y)
# visualize(pred, color=dataset.y)
pred = pred.argmax(dim=2)
pred=pred[0]

t_y=torch.LongTensor(y)
report = classification_report(le.inverse_transform(t_y[dataset.test_mask]),
                               le.inverse_transform(pred[dataset.test_mask]), output_dict=True)
report = pd.DataFrame(report).T
# # 构建一个简单的图数据（这里只是一个示例，具体的图数据构建需根据你的数据格式来）
# x = torch.rand((num_nodes, num_features))  # 代表每个节点的特征
# edge_index = torch.tensor(edge_index, dtype=torch.long)  # 图的边关系
#
# data = Data(x=x, edge_index=edge_index.t().contiguous())
#
# # 初始化GCN模型
# input_size = num_features
# hidden_size = 64
# output_size = num_classes
#
# model = GCN(input_size, hidden_size, output_size)
#
# # 定义损失函数和优化器
# criterion = nn.CrossEntropyLoss()
# optimizer = optim.Adam(model.parameters(), lr=0.01)
#
# # 训练模型
# num_epochs = 100
#
# for epoch in range(num_epochs):
#     optimizer.zero_grad()
#     output = model(data)
#     loss = criterion(output[train_mask], labels[train_mask])  # 使用训练集计算损失
#     loss.backward()
#     optimizer.step()
#
#     # 输出每轮训练的准确度
#     with torch.no_grad():
#         pred = output.argmax(dim=1)
#         acc_train = (pred[train_mask] == labels[train_mask]).sum().item() / train_mask.sum().item()
#         print(f'Epoch {epoch + 1}/{num_epochs}, Loss: {loss.item()}, Train Acc: {acc_train}')
#
# # 在测试集上评估模型
# with torch.no_grad():
#     output = model(data)
#     pred = output.argmax(dim=1)
#     acc_test = (pred[test_mask] == labels[test_mask]).sum().item() / test_mask.sum().item()
#     print(f'Test Accuracy: {acc_test}')
