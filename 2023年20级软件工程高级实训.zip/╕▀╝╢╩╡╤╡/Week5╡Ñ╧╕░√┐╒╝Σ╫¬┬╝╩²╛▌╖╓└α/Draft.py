import numpy as np

# 创建一个 3x3 的矩阵
dists_mask = np.random.rand(3, 3)

print("原始矩阵:")
print(dists_mask)

# 将对角线元素设置为 0
np.fill_diagonal(dists_mask, 0)

print("\n处理后的矩阵:")
print(dists_mask)