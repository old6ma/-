import pandas as pd
import numpy as np
from tqdm import tqdm
from sklearn.metrics import pairwise_distances
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score
import torch
from torch import nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.data import Data

# train_df是1752*48的Dataframe
train_df = pd.read_csv("st_training_set.csv", index_col=0)
# test_df是1800*48的Dataframe
test_df = pd.read_csv("st_test_set.csv", index_col=0)
# 把test_df与data_df合并，此时训练集数据的索引为0~1751，测试集的索引为1752~3551
df = pd.concat((train_df, test_df))
# 构建一个数值在0~1751的一维张量作为训练集的mask（此时训练集数据的索引为0~1751）
train_mask = torch.arange(train_df.shape[0])
# 构建一个数值在1752~3551的一维张量作为测试集的mask（此时测试集的索引为1752~3551）
test_mask = torch.arange(train_df.shape[0], df.shape[0])


# df


# 如果两个细胞的距离小于给定阈值，则在两个细胞间构边
def get_edge_index(pos, distance_thres=10):
    edge_list = []
    # 计算各个细胞两两之间的距离，从而构边（dists是3552*3552的矩阵）
    dists = pairwise_distances(pos)
    # 保留值小于预定阈值的距离，即对应两个细胞间存在边，对应mask为True（有边），反之对应mask为false（没边），很少元素为True
    dists_mask = dists < distance_thres
    print(dists_mask)
    # 把对角线元素设置为False
    np.fill_diagonal(dists_mask, 0)
    print(dists_mask)
    # 获得每条边所连接的两个点的索引
    edge_list = np.transpose(np.nonzero(dists_mask))
    return edge_list


# 取数据中x、y列的坐标值作为每个细胞的位置
pos = df.iloc[:, -4:-2].values
edge_index = get_edge_index(pos)

# 每个细胞的所有44个基因的特征值
x = df.iloc[:, :-4].values
# 细胞类型
y = df['cell_type'].values
# labelEncoder用于把标签转化为整数类型
le = LabelEncoder()
y = le.fit_transform(y)

dataset = Data(x=torch.FloatTensor(x),
               edge_index=torch.LongTensor(edge_index).T,
               y=torch.LongTensor(y))

dataset.train_mask = train_mask
dataset.test_mask = test_mask


class GCN(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, num_classes):
        super().__init__()
        self.conv1 = GCNConv(input_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, num_classes)

    def forward(self, data):
        x, edge_index = data.x, data.edge_index

        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, training=self.training)
        x = self.conv2(x, edge_index)

        return F.log_softmax(x, dim=1)


model = GCN(dataset.x.shape[1], 32, np.unique(dataset.y).shape[0])
optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=5e-4)

model.train()
for epoch in tqdm(range(300)):
    optimizer.zero_grad()
    out = model(dataset)
    loss = F.nll_loss(out[dataset.train_mask], dataset.y[dataset.train_mask])
    loss.backward()
    optimizer.step()

model.eval()
pred = model(dataset).argmax(dim=1)

report = classification_report(le.inverse_transform(dataset.y[dataset.test_mask]),
                               le.inverse_transform(pred[dataset.test_mask]), output_dict=True)
report = pd.DataFrame(report).T
report
