from torch_geometric.nn import GCNConv
import torch
import torch.nn.functional as F
from torch_geometric.datasets import Planetoid
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

dataset = Planetoid(root='./tmp/Cora', name='Cora')
print(dataset.num_features)
# Cora节点类别数量
print(dataset.num_classes)
print(dataset.data)


def visualize(h, color):
    z = TSNE(n_components=2).fit_transform(h.detach().cpu().numpy())

    plt.figure(figsize=(10, 10))
    plt.xticks([])
    plt.yticks([])

    plt.scatter(z[:, 0], z[:, 1], s=70, c=color, cmap="Set2")
    plt.show()


class GCN(torch.nn.Module):

    def __init__(self, hidden_dimension):
        super(GCN, self).__init__()
        # GCNConv函数是GCN网络的卷积层，用于计算每一层结点的特征（根据学习报告中的原理），有两个参数分别是输入特征通道数与输出特征通道数
        # 第一层卷积层把每个结点的特征维度传入到中间层上，所以第一层的输入输出特征通道数分别为输入结点特征维度与隐藏层维度
        self.conv1 = GCNConv(dataset.num_features, hidden_dimension)
        # 第二层把中间层的特征映射到最终的类别上，比如Cora数据集最终要辨别7种论文，那么对应的输出特征维度就为7
        self.conv2 = GCNConv(hidden_dimension, dataset.num_classes)

    def forward(self, data):
        # 传入结点与边（即节点的邻接关系）
        x, edge_index = data.x, data.edge_index
        # 把结点与邻接关系导入第一层卷积，网络会根据输入特征和边关系来执行图卷积操作，将特征传给邻居节点
        x = self.conv1(x, edge_index)
        # 激活函数
        x = x.relu()
        # dropout层用于防止过拟合
        x = F.dropout(x, training=self.training)
        # 把上一层处理好的特征再传入下一层卷积层，作用与第一层一样，区别在于输出的特征维度已经是dataset.num_classes了
        x = self.conv2(x, edge_index)
        # 使用softmax得到概率分布
        x = F.log_softmax(x, dim=1)
        return x


# Cora是一个单图数据集，所以dataset中只有一个图，取出dataset[0]即可
data = dataset[0]
# 实例化模型，优化器与损失函数的处理与CNN是一样的
model = GCN(hidden_dimension=16)
optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=0.001)
criterion = torch.nn.CrossEntropyLoss()

out = model(data)
# 展示未分类过的结点
visualize(out, color=data.y)

model.train()
for epoch in range(1, 100):
    optimizer.zero_grad()
    predict = model(data)
    loss = criterion(predict[data.train_mask], data.y[data.train_mask])
    loss.backward()
    # 更新参数的值
    optimizer.step()
    # print(data.train_mask)
    # print(predict)
    # print(data.y)
    # 每20次训练用验证集检验一次训练效果
    if epoch % 20 == 0:
        model.eval()
        output = model(data)
        # 输出预测结果
        pred = output.argmax(dim=1)
        # 检验预测结果与真实标签相同的个数，即正确个数
        correct = pred[data.val_mask].eq(data.y[data.val_mask]).sum().item()
        acc = correct / data.val_mask.sum().item()
        print(f'Val_data accuracy is: {acc:.4f}')
    print(f'Epoch: {epoch:03d}, Loss: {loss:.4f}')

model.eval()
# 操作与验证集同理
pred = model(data)
pred = pred.argmax(dim=1)
test_correct = pred[data.test_mask] == data.y[data.test_mask]
test_acc = int(test_correct.sum()) / int(data.test_mask.sum())
print(f'Test Accuracy: {test_acc:.4f}')

pred = model(data)
# 显示分类后的结果
visualize(pred, color=data.y)
